﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationSample2.Controllers
{
    [Route("Pack")]
    public class PackManagementController : Controller
    {

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create()
        {
            return View();
        }
    }
}
