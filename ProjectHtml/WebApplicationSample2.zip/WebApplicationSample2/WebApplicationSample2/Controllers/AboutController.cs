﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplicationSample2.Controllers
{
    
    public class AboutController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Technical()
        {
            return View();
        }

        public IActionResult Experience()
        {
            return View();
        }

        public IActionResult Education()
        {
            return View();
        }

        [Route("Awards")]
        public IActionResult Awards()
        {
            ViewBag.count = 20;
            ViewData["one"] = 12;
            return View();
        }



        
    }
}
